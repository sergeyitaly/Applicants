# Upcoming Features

* Support for Plotly animations
* Images within the bars
* Names within bars (as opposed to just tick labels)
* Tools to see colormaps

## Request a feature

Request a feature by [creating an issue on github](https://github.com/dexplo/bar_chart_race/issues).
